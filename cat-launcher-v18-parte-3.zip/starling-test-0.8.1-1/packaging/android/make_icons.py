#!/usr/bin/env python3
"""Cat Launcher's icon resources, made from icons/cat-launcher.jpg (the cat, as given: it is only
scaled, never redrawn or recoloured).

    python3 packaging/android/make_icons.py

Writes into packaging/android/res/ (build_apk.py copies that folder into the APK):
  mipmap-*dpi/ic_launcher.png            the picture itself, for each density
  mipmap-*dpi/ic_launcher_foreground.png the adaptive icon's 108 dp layer: the picture at 56% of
                                         it, so the whole cat stays inside the 66 dp safe zone of
                                         any mask (circle, squircle...), on the picture's own colour
  mipmap-anydpi-v26/ic_launcher.xml      the adaptive icon (Android 8 and up: the home screen, the
                                         app list, Settings)
  values/ic_launcher_background.xml      the adaptive icon's background: the picture's colour
Needs Pillow.
"""
from pathlib import Path
from PIL import Image

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "icons" / "cat-launcher.jpg"
RES = HERE / "res"
DENSITIES = {"mdpi": 1, "hdpi": 1.5, "xhdpi": 2, "xxhdpi": 3, "xxxhdpi": 4}
# The farthest point of the cat from the picture's centre is 589/540 of its half-width; the safe
# zone's radius is 33 dp: half-width 30.24 dp, a picture of 60.48 dp, 56% of 108.
FOREGROUND_SHARE = 0.56


def background(img):
    """The picture's own background colour: the median of its border pixels."""
    w, h = img.size
    px = img.load()
    edge = [px[x, y] for x in range(0, w, 4) for y in (0, 1, h - 2, h - 1)]
    edge += [px[x, y] for y in range(0, h, 4) for x in (0, 1, w - 2, w - 1)]
    return tuple(sorted(c[i] for c in edge)[len(edge) // 2] for i in range(3))


def main():
    img = Image.open(SOURCE).convert("RGB")
    bg = background(img)
    for name, scale in DENSITIES.items():
        folder = RES / f"mipmap-{name}"
        folder.mkdir(parents=True, exist_ok=True)
        icon = round(48 * scale)
        img.resize((icon, icon), Image.LANCZOS).save(folder / "ic_launcher.png", optimize=True)
        layer = round(108 * scale)
        canvas = Image.new("RGB", (layer, layer), bg)
        side = round(layer * FOREGROUND_SHARE)
        at = (layer - side) // 2
        canvas.paste(img.resize((side, side), Image.LANCZOS), (at, at))
        canvas.save(folder / "ic_launcher_foreground.png", optimize=True)
    adaptive = RES / "mipmap-anydpi-v26"
    adaptive.mkdir(parents=True, exist_ok=True)
    (adaptive / "ic_launcher.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
        '    <background android:drawable="@color/ic_launcher_background" />\n'
        '    <foreground android:drawable="@mipmap/ic_launcher_foreground" />\n'
        "</adaptive-icon>\n",
        encoding="utf-8",
    )
    (RES / "values").mkdir(parents=True, exist_ok=True)
    (RES / "values" / "ic_launcher_background.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
        f'    <color name="ic_launcher_background">#{bg[0]:02X}{bg[1]:02X}{bg[2]:02X}</color>\n'
        "</resources>\n",
        encoding="utf-8",
    )
    print("background", bg)


if __name__ == "__main__":
    main()

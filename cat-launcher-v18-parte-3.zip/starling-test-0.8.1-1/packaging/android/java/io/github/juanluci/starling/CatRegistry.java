package io.github.juanluci.starling;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;

/**
 * Cat Launcher's permanent record of the Minecraft versions (SQLite in the app's private
 * databases folder: it survives closing the app, rebooting and updating the APK; only clearing
 * the app's data or uninstalling it removes it). The game files themselves stay in the engine's
 * folders; this table only says which versions were really installed, when, and in what state.
 *
 * States: INSTALLING (started, not finished: an interrupted install is recognised by it),
 * INSTALLED (files downloaded AND prepared, as the engine reported), DAMAGED (was installed,
 * the engine no longer finds it complete: still listed so it never just vanishes; installing again
 * reuses every file whose hash is still good).
 */
final class CatRegistry extends SQLiteOpenHelper {
    static final String INSTALLING = "installing";
    static final String INSTALLED = "installed";
    static final String DAMAGED = "damaged";

    private static CatRegistry instance;

    static synchronized CatRegistry get(Context any) {
        if (instance == null) {
            instance = new CatRegistry(any.getApplicationContext());
        }
        return instance;
    }

    private CatRegistry(Context context) {
        super(context, "cat-registry.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE versions (id TEXT PRIMARY KEY NOT NULL, state TEXT NOT NULL, "
                + "installed_at INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int from, int to) {
        // Version 1 is the first schema; later versions migrate here without dropping the table.
    }

    private void put(String id, String state, boolean stampInstalled) {
        long now = System.currentTimeMillis();
        SQLiteDatabase db = getWritableDatabase();
        ContentValues row = new ContentValues();
        row.put("state", state);
        row.put("updated_at", now);
        if (stampInstalled) {
            row.put("installed_at", now);
        }
        if (db.update("versions", row, "id = ?", new String[] {id}) == 0) {
            row.put("id", id);
            db.insert("versions", null, row);
        }
    }

    synchronized void markInstalling(String id) {
        put(id, INSTALLING, false);
    }

    /** Only after the engine reported files ready and prepared. */
    synchronized void markInstalled(String id) {
        if (!INSTALLED.equals(stateOf(id))) {
            put(id, INSTALLED, true);
        }
    }

    synchronized void markDamaged(String id) {
        if (INSTALLED.equals(stateOf(id))) {
            put(id, DAMAGED, false);
        }
    }

    synchronized void remove(String id) {
        getWritableDatabase().delete("versions", "id = ?", new String[] {id});
    }

    synchronized String stateOf(String id) {
        try (Cursor c = getReadableDatabase().query("versions", new String[] {"state"}, "id = ?",
                new String[] {id}, null, null, null)) {
            return c.moveToFirst() ? c.getString(0) : null;
        }
    }

    /** Ids in `state`, as a JSON array. */
    synchronized JSONArray idsIn(String... states) {
        JSONArray out = new JSONArray();
        try (Cursor c = getReadableDatabase().query("versions", new String[] {"id", "state"}, null,
                null, null, null, "installed_at, id")) {
            while (c.moveToNext()) {
                for (String s : states) {
                    if (s.equals(c.getString(1))) {
                        out.put(c.getString(0));
                    }
                }
            }
        }
        return out;
    }
}

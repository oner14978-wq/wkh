package io.github.juanluci.starling;

import android.app.Activity;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

/**
 * Cat Launcher's purple loading screen, over the game's window from the tap on JOGAR until the
 * game is ready for the player. It shows what the engine reports in cat-progress.json
 * (cat_progress.rs writes it as real stages finish); it never moves the bar by itself.
 * States: working (shown), needs_input / failed (hidden: the game's own screen, with its sign-in
 * or retry, is what the player needs), ready (100 %, then gone).
 */
final class CatLoadingOverlay {
    static final String FILE = "cat-progress.json";
    private static final long POLL_MS = 150;

    private final Activity activity;
    private final File file;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView view;
    private boolean pageReady;
    private boolean finished;
    private int pct;
    private String step = "Preparando os arquivos da versão";
    private String detail = "";
    private String lastRaw = "";

    CatLoadingOverlay(Activity activity) {
        this.activity = activity;
        this.file = new File(activity.getFilesDir(), FILE);
    }

    /** Before the game starts: a file left by an earlier run must not be taken for this one. */
    static void reset(Activity activity) {
        new File(activity.getFilesDir(), FILE).delete();
    }

    void show() {
        view = new WebView(activity);
        view.setBackgroundColor(Color.BLACK);
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(true);
        view.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView page, String url) {
                pageReady = true;
                push();
            }
        });
        view.loadUrl("file:///android_asset/cat/loading.html");
        activity.addContentView(view, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        handler.post(poll);
    }

    void stop() {
        finished = true;
        handler.removeCallbacksAndMessages(null);
        remove();
    }

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (finished) {
                return;
            }
            read();
            if (!finished) {
                handler.postDelayed(this, POLL_MS);
            }
        }
    };

    private void read() {
        String raw = slurp();
        if (raw == null || raw.equals(lastRaw)) {
            return;
        }
        lastRaw = raw;
        try {
            JSONObject json = new JSONObject(raw);
            String state = json.optString("state", "working");
            pct = Math.max(pct, json.optInt("pct", 0));
            String said = json.optString("step", "");
            if (!said.isEmpty()) {
                step = said;
            }
            detail = json.optString("detail", "");
            if ("ready".equals(state)) {
                pct = 100;
                push();
                finished = true;
                // The bar is seen at 100 for a moment, then the game is there.
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        remove();
                    }
                }, 350);
            } else if ("working".equals(state)) {
                if (view != null) {
                    view.setVisibility(View.VISIBLE);
                }
                push();
            } else if (view != null) {
                // needs_input / failed: the game's own screen is what the player needs now.
                view.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            android.util.Log.w("starling", "unreadable " + FILE, e);
        }
    }

    private void push() {
        if (view == null || !pageReady) {
            return;
        }
        view.evaluateJavascript("window.catProgress(" + pct + "," + JSONObject.quote(step) + ","
                + JSONObject.quote(detail) + ")", null);
    }

    private void remove() {
        if (view == null) {
            return;
        }
        ViewGroup parent = (ViewGroup) view.getParent();
        if (parent != null) {
            parent.removeView(view);
        }
        view.destroy();
        view = null;
    }

    private String slurp() {
        if (!file.isFile()) {
            return null;
        }
        try (InputStream in = new FileInputStream(file)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int n;
            while ((n = in.read(buffer)) > 0) {
                out.write(buffer, 0, n);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }
}

package io.github.juanluci.starling;

import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.regex.Pattern;

/** Offline profile rules shared by the launcher: 3-16 [A-Za-z0-9_] and Minecraft's offline UUID. */
final class OfflineProfile {
    private static final Pattern NAME = Pattern.compile("^[A-Za-z0-9_]{3,16}$");

    private OfflineProfile() {}

    static boolean validName(String name) {
        return name != null && NAME.matcher(name).matches();
    }

    static String offlineUuid(String name) {
        return UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8)).toString();
    }
}

package io.github.juanluci.starling;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import java.security.Key;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

/**
 * Java side of Cat Launcher's bridge: HTML (window.CatNative.core) -> here -> JNI -> Rust
 * (crates/horizon-client/src/cat_bridge.rs) -> the game's own systems (accounts, official-file
 * downloads, skins). Loads the game's library in the launcher's process (":cat") and gives Rust
 * the platform's pieces it asks for: the Keystore (the same key as StarlingActivity's, so the
 * accounts sealed here open in the game), the browser, the foreground service.
 */
final class CatCore {
    private static Context context;
    private static String started;

    private CatCore() {}

    /** Starts the library's bridge once; "" when it is ready, else the reason. */
    static synchronized String start(Context any) {
        if (started != null) {
            return started;
        }
        context = any.getApplicationContext();
        String result;
        try {
            System.loadLibrary("horizon_android");
            String shared = StarlingActivity.sharedFolder(context);
            String priv = context.getFilesDir().getPath();
            result = init(priv, shared != null ? shared : priv);
        } catch (UnsatisfiedLinkError e) {
            android.util.Log.e("starling", "the game library has no Cat Launcher bridge", e);
            result = "A biblioteca nativa do motor não carregou ou não tem a ponte do Cat Launcher: "
                    + e.getMessage();
        }
        if (result.isEmpty()) {
            started = result;
        }
        return result;
    }

    /** JSON answer of the Rust system for `method`; {"ok":false,"error":..} if the bridge is down. */
    static String request(String method, String args) {
        if (context == null) {
            return "{\"ok\":false,\"error\":\"a ponte nativa ainda não recebeu o contexto do app\"}";
        }
        String up = start(context);
        if (!up.isEmpty()) {
            return "{\"ok\":false,\"error\":" + org.json.JSONObject.quote(up) + "}";
        }
        try {
            return call(method, args == null ? "{}" : args);
        } catch (UnsatisfiedLinkError e) {
            return "{\"ok\":false,\"error\":" + org.json.JSONObject.quote(String.valueOf(e.getMessage())) + "}";
        }
    }

    /** Remembers the context for requests that arrive before start() (the activity calls it first). */
    static void attach(Context any) {
        if (context == null) {
            context = any.getApplicationContext();
        }
    }

    private static native String init(String privateDir, String gameHome);

    private static native String call(String method, String args);

    // ---- what Rust calls back (cat_bridge.rs hooks) ----

    static boolean openLink(String url) {
        if (url == null || !url.startsWith("https://")) {
            return false;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return true;
        } catch (ActivityNotFoundException | SecurityException e) {
            return false;
        }
    }

    /** A file of the APK's assets, for the engine (preparer kit, skin): null when it is not there. */
    static byte[] asset(String name) {
        try (java.io.InputStream in = context.getAssets().open(name)) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buffer = new byte[65536];
            int n;
            while ((n = in.read(buffer)) > 0) {
                out.write(buffer, 0, n);
            }
            return out.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    static String libraryDir() {
        return context.getApplicationInfo().nativeLibraryDir;
    }

    static void keepWorking(String reason, String line, boolean on) {
        WorkService.hold(context, reason, line, on);
    }

    /** Same key name and cipher as StarlingActivity.sealSecret: one Keystore key for both. */
    private static final String SECRET_KEY = "starling-account";

    private static SecretKey secretKey() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        Key key = store.getKey(SECRET_KEY, null);
        if (key instanceof SecretKey) {
            return (SecretKey) key;
        }
        KeyGenerator generator =
                KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(SECRET_KEY,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build());
        return generator.generateKey();
    }

    static byte[] sealSecret(byte[] data) {
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey());
            byte[] iv = cipher.getIV();
            byte[] sealed = cipher.doFinal(data);
            byte[] out = new byte[1 + iv.length + sealed.length];
            out[0] = (byte) iv.length;
            System.arraycopy(iv, 0, out, 1, iv.length);
            System.arraycopy(sealed, 0, out, 1 + iv.length, sealed.length);
            return out;
        } catch (Exception e) {
            return null;
        }
    }

    static byte[] openSecret(byte[] sealed) {
        try {
            int ivLength = sealed[0] & 0xFF;
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, secretKey(),
                    new GCMParameterSpec(128, sealed, 1, ivLength));
            return cipher.doFinal(sealed, 1 + ivLength, sealed.length - 1 - ivLength);
        } catch (Exception e) {
            return null;
        }
    }
}

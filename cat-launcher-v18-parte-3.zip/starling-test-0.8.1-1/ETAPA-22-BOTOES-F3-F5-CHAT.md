# ETAPA 22 - botões F3, Chat, F5 e engrenagem - NÃO COMPILADO, NÃO TESTADO (sem cargo/NDK/aparelho)

Achado por leitura: no Android os cinco botões já existiam (Control::Debug, Chat, Perspective, Pause, Settings em android_controls.rs),
com toque tratado em mobile_controls/mod.rs (mobile_frame). Não recriei nada.
- F3: já usava debug_key(F3 press+release) = igual à tecla. Mantido.
- Chat e F5: usavam toques de D-pad do gamepad (DPadRight/DPadUp), sem ligação confirmada com chat/câmera.
  Agora chamam mobile_key_tap(KeyCode::KeyT / F5): mesmo caminho do teclado (debug_key -> key_pressed), que abre o chat real
  (open_chat_method) e cicla a câmera (cycle_camera); o chat abre o teclado do Android. Só com Screen::Playing e sem título.
  Trava contra repetição: tecla já em physical_keys não dispara de novo.
- Engrenagem: só existe um Control::Settings (abre open_options). O hub flutuante e o painel H/... estão ocultos por CAT_HIDE_HORIZON_BUTTONS.
  Não achei no código um segundo botão de configurações; se aparecer outro no aparelho, preciso de um print.
- Ordem padrão da fileira: F3, Chat, F5, Pausa, Engrenagem. Layouts já salvos no aparelho NÃO mudam (só instalação nova/reset).
- Não testado: compilação, toque no Android, multiplayer, convivência com o movimento.

## V16 - por que F3/F5 não apareciam (lido no código, não visto no aparelho)
- Debug/Chat/Perspective só desenhavam se o layout salvo (horizon-touch.json) não os escondesse (visible_in_game/button_visibility) e
  sem use_goy_style; o ícone de F3/F5 era um desenho de pixels sem o texto F3/F5.
- Agora, no estilo MCPE, always_shown() torna os três sempre visíveis na partida e o desenho é próprio: placa violeta com "F3" / "F5"
  (label_plate) e o balão de chat. O toque continua o mesmo (debug_key F3; Chat e F5 pelo teclado real em mobile_key_tap).
- Engrenagem: continua um só Control::Settings (abre as opções). Não existe outro botão de configurações ativo no código
  (hub flutuante e '...' ocultos por CAT_HIDE_HORIZON_BUTTONS). Pausa é outro botão (menu de pausa).
- No estilo GoyControl os botões são os personalizados DEBUG / 3RD / CHAT (já existentes); os de MCPE não aparecem aí, para não duplicar.

## V17 - GoyControl
- always_shown(): MCPE sempre; GoyControl também, a não ser que um botão personalizado (key/second_key/third_key) já envie
  key.keyboard.f3 / t / f5. Assim os três botões existem nos dois estilos sem aparecer em dobro. Engrenagem não mexida.

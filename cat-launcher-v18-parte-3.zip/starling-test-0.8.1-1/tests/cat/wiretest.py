# Teste da FIAÇÃO do index.html: um "CatNative" de teste registra cada chamada feita pelos botões.
# Isto NÃO testa o motor: só prova que cada botão chama core()/installVersion()/launch()/saveSkin().
import json, sys
from playwright.sync_api import sync_playwright
HTML='file:///home/claude/full/starling-test-0.8.1-1/packaging/android/cat/index.html'
INIT = """
window.__calls=[]; window.__state={account:{kind:'offline'},files:{kind:'missing'}};
window.CatNative={
 core(m,a){__calls.push(['core',m,a]);
   if(m==='state')return JSON.stringify({ok:true,account:__state.account,files:__state.files,profiles:{},version:'26.3'});
   if(m==='add_offline'){const n=JSON.parse(a).name;return JSON.stringify(/^[A-Za-z0-9_]{3,16}$/.test(n)?{ok:true}:{ok:false,error:'Nome inválido para o jogo'})}
   if(m==='sign_in_microsoft'){__state.account={kind:'code',code:'ABCD1234',link:'https://microsoft.com/link'};return JSON.stringify({ok:true})}
   return JSON.stringify({ok:true})},
 listVersions(){__calls.push(['listVersions']);return JSON.stringify([{id:'26.3',type:'release',cat:'recent',installed:false}])},
 installedVersions(){__calls.push(['installedVersions']);return JSON.stringify(__state.files.kind==='ready'?['26.3']:[])},
 installVersion(id){__calls.push(['installVersion',id]);__state.files={kind:'downloading',files:3,files_total:10,bytes:30e6,bytes_total:100e6};return ''},
 launch(v,s){__calls.push(['launch',v,s]);return ''},
 removeVersion(id){__calls.push(['removeVersion',id]);return ''},
 saveSkin(j){__calls.push(['saveSkin',JSON.parse(j).png?'png-presente':'sem-png']);return ''},
 immersive(){}, microsoftLogin(){__calls.push(['microsoftLogin(antigo)'])}};
"""
res={}
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1280,'height':720})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.add_init_script(INIT); pg.goto(HTML); pg.wait_for_timeout(800)
    # 1 lista de versões vem da ponte
    pg.click('#bAdd'); pg.wait_for_timeout(300)
    res['versoes_listadas_pela_ponte']=pg.evaluate("__calls.some(c=>c[0]==='listVersions')")
    # 2 instalar -> installVersion + acompanha core('state')
    pg.evaluate("document.querySelector('[data-i=\"26.3\"]').click()"); pg.wait_for_timeout(1000)
    res['instalar_chama_installVersion']=pg.evaluate("__calls.some(c=>c[0]==='installVersion'&&c[1]==='26.3')")
    res['progresso_vem_do_state']=pg.evaluate("document.querySelector('#inst').textContent")
    pg.evaluate("__state.files={kind:'ready'}"); pg.wait_for_timeout(1000)
    res['ao_ficar_ready']=pg.evaluate("document.querySelector('#inst').textContent")
    # 3 criar conta -> core('add_offline') com nome inválido e válido
    pg.evaluate("go('home')"); pg.evaluate("showAcc('signup')")
    def fill(u): 
        pg.fill('#f_u',u); pg.fill('#f_e','a@b.co'); pg.fill('#f_p','12345678'); pg.fill('#f_p2','12345678'); pg.click('#accOk'); pg.wait_for_timeout(400)
    pg.on('dialog',lambda d:d.accept())
    fill('Jo!')
    res['conta_nome_invalido_msg']=pg.evaluate("document.querySelector('#accM').textContent")
    res['sessao_apos_invalido']=pg.evaluate("localStorage.getItem('cat:session')")
    fill('Gatinho_01')
    res['sessao_apos_valido']=pg.evaluate("localStorage.getItem('cat:session')")
    # 4 Microsoft -> core('sign_in_microsoft') + mostra código + open_link
    pg.evaluate("showAcc('login')"); pg.click('#ms'); pg.wait_for_timeout(500)
    res['ms_texto']=pg.evaluate("document.querySelector('#accM').textContent")
    pg.evaluate("__state.account={kind:'signed_in',name:'MsPlayer',key:'k',provider:'microsoft'}"); pg.wait_for_timeout(1300)
    res['ms_sessao']=pg.evaluate("localStorage.getItem('cat:session')")
    # 5 JOGAR
    pg.evaluate("go('home')"); pg.click('#bPlay'); pg.wait_for_timeout(300)
    res['jogar_chama_launch']=pg.evaluate("JSON.stringify(__calls.filter(c=>c[0]==='launch'))")
    # 6 salvar skin
    pg.evaluate("go('cust')"); pg.wait_for_timeout(500); pg.click('#bSave'); pg.wait_for_timeout(200)
    res['salvar_skin']=pg.evaluate("JSON.stringify(__calls.filter(c=>c[0]==='saveSkin'))")
    res['metodos_core_chamados']=pg.evaluate("[...new Set(__calls.filter(c=>c[0]==='core').map(c=>c[1]))]")
    res['erros_js']=errs
    b.close()
print(json.dumps(res,ensure_ascii=False,indent=1))

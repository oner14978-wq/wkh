# Teste da interface do Cat Launcher (index.html) em Chromium REAL, com um "motor" SIMULADO em JavaScript
# (CatNative.core imita as respostas do cat_bridge.rs: valida o nome, guarda o perfil offline e devolve o UUID).
# Isto testa a interface e a fiação; NÃO testa o Rust/Java nem o Minecraft de verdade.
import json, hashlib, sys, uuid, os, shutil, tempfile
from playwright.sync_api import sync_playwright
HTML = os.environ.get('CAT_HTML', 'file://' + os.path.abspath(os.path.join(os.path.dirname(__file__), '../../packaging/android/cat/index.html')))
OUT = os.environ.get('CAT_OUT', '/home/claude/work/out')
def offline_uuid(name):  # UUID.nameUUIDFromBytes("OfflinePlayer:"+name) do Java
    h = bytearray(hashlib.md5(('OfflinePlayer:' + name).encode()).digest()); h[6] = (h[6] & 0x0f) | 0x30; h[8] = (h[8] & 0x3f) | 0x80
    return str(uuid.UUID(bytes=bytes(h)))
NAMES = ['Gatinho_01', 'Steve', 'Alex_2', 'Outro_Nome']
UU = {n: offline_uuid(n) for n in NAMES}
INIT = """
window.__calls=[]; Element.prototype.requestFullscreen=function(){return Promise.resolve()}; const UU=%s;
const eng=()=>{try{return JSON.parse(localStorage.getItem('ENGINE')||'{"offline":[],"sel":null}')}catch(e){return{offline:[],sel:null}}};
const put=e=>localStorage.setItem('ENGINE',JSON.stringify(e));
window.CatNative={
 core(m,a){const args=JSON.parse(a||'{}');__calls.push(['core',m,args]);
  if(m==='state'){const e=eng();const u={};e.offline.forEach(n=>u[n]=UU[n]||'00000000-0000-3000-8000-000000000000');return JSON.stringify({ok:true,account:{kind:e.sel?'offline_profile':'offline',name:e.sel},profiles:{offline:e.offline,offline_selected:e.sel,uuids:u},files:{kind:'missing'},version:'26.3'})}
  if(m==='add_offline'){const n=(args.name||'').trim();if(!/^[A-Za-z0-9_]{3,16}$/.test(n))return JSON.stringify({ok:false,error:'Nome inválido para o jogo: use de 3 a 16 letras, números ou _.'});
   const e=eng();if(!e.offline.includes(n))e.offline.push(n);e.sel=n;put(e);return JSON.stringify({ok:true,name:n,uuid:UU[n]||'00000000-0000-3000-8000-000000000000'})}
  return JSON.stringify({ok:true})},
 listVersions(){return JSON.stringify([{id:'26.3',type:'release',cat:'recent',installed:true}])},
 installedVersions(){return JSON.stringify(['26.3'])}, installVersion(){return ''},
 launch(v,s){__calls.push(['launch',v,s]);return ''}, removeVersion(){return ''},
 saveSkin(j){const o=JSON.parse(j);__calls.push(['saveSkin',{png:(o.png||'').slice(0,22),sel:o.sel,model:o.model,img:!!o.img}]);window.__lastPng=o.png;return ''}, immersive(){}};
""" % json.dumps(UU)
R = {}; fails = []
def check(name, cond, extra=None):
    R[name] = bool(cond) if extra is None else {'ok': bool(cond), 'info': extra}
    if not cond: fails.append(name)
HEAD_BASE = "(()=>{const d=tc.getContext('2d').getImageData(0,0,32,16).data;return Array.from(d).join(',')})()"
HAIRCOUNT = "(()=>{const d=tc.getContext('2d').getImageData(0,0,32,16).data;let n=0;for(let i=0;i<d.length;i+=4){if(d[i+3]===255&&d[i]<80&&d[i+1]<60&&d[i+2]<40)n++}return n})()"
def main():
    prof = tempfile.mkdtemp(prefix='catprof')
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(prof, viewport={'width': 911, 'height': 404}, args=['--allow-file-access-from-files'])
        pg = ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append('console:' + m.text) if m.type == 'error' and 'ERR_NAME_NOT_RESOLVED' not in m.text else None)  # a fonte Lexend (Google Fonts) já existia e não carrega sem rede
        pg.on('dialog', lambda d: d.accept())
        pg.add_init_script(INIT); pg.goto(HTML); pg.wait_for_timeout(700)
        modal_on = lambda: pg.evaluate("document.querySelector('#mOff').classList.contains('on')")
        # 1) JOGAR sem conta abre a tela Conta Offline
        pg.click('#bPlay'); pg.wait_for_timeout(500)
        check('1_jogar_sem_conta_abre_tela', modal_on())
        check('1_nao_chamou_launch', not pg.evaluate("__calls.some(c=>c[0]==='launch')"))
        pg.screenshot(path=OUT + '/conta_offline_911x404.png')
        pg.set_viewport_size({'width': 1822, 'height': 808}); pg.wait_for_timeout(300); pg.screenshot(path=OUT + '/conta_offline_1822x808.png'); pg.set_viewport_size({'width': 911, 'height': 404}); pg.wait_for_timeout(300)
        # 2) elementos obrigatórios
        txt = pg.evaluate("document.querySelector('#mOff').innerText")
        check('2_textos', all(t in txt for t in ['Conta Offline', 'Você pode jogar offline usando um', 'nome de jogador personalizado.', 'Nome do Jogador:', 'Este nome será usado apenas offline.', 'Cancelar', 'Criar Conta']), txt)
        check('2_sem_microsoft_nem_senha', not pg.evaluate("/microsoft|senha|e-mail|login|entrar/i.test(document.body.innerHTML.replace(/data:[^\"')]+/g,''))"))
        geo = pg.evaluate("""(()=>{const g=s=>{const r=document.querySelector(s).getBoundingClientRect();return[Math.round(r.left),Math.round(r.top),Math.round(r.width),Math.round(r.height)]};return{input:g('#offName'),cancel:g('#offCancel'),ok:g('#offOk'),panel:g('#offPanel'),steve:g('#offSteve')}})()""")
        check('2_geometria_igual_a_referencia', geo['input'] == [307, 210, 586, 53] and geo['cancel'][:2] == [299, 320] and geo['ok'][:2] == [624, 320] and geo['panel'][:2] == [279, 14], geo)
        steve_px = pg.evaluate("(()=>{const c=document.querySelector('#offSteve'),d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i]>200)n++;return n})()")
        check('2_steve_desenhado', steve_px > 5000, steve_px)
        # 3) validação e criação real
        for bad, label in [('', 'vazio'), ('ab', 'curto')]:
            pg.fill('#offName', bad)
            pg.click('#offOk'); pg.wait_for_timeout(150)
            check('3_rejeita_' + label, pg.evaluate("document.querySelector('#offHint').classList.contains('err')") and not pg.evaluate("__calls.some(c=>c[0]==='core'&&c[1]==='add_offline')"))
        check('3_validacao_17_chars_e_simbolos', pg.evaluate("validName('a'.repeat(17))!==''&&validName('ab cd')!==''&&validName('ab-cd')!==''&&validName('Ábc')!==''&&validName('abc')===''&&validName('A_1'.repeat(5))===''"))
        check('3_input_limita_16', pg.evaluate("document.querySelector('#offName').maxLength")==16)
        pg.fill('#offName', 'Jo Ão!'); pg.wait_for_timeout(100)
        check('3_filtra_caracteres_invalidos', pg.input_value('#offName') == 'Joo', pg.input_value('#offName'))
        pg.fill('#offName', 'Gatinho_01'); pg.click('#offOk'); pg.wait_for_timeout(400)
        check('3_fecha_tela_apos_criar', not modal_on())
        eng = pg.evaluate("JSON.parse(localStorage.getItem('ENGINE'))"); loc = pg.evaluate("store.get('offline')")
        check('3_motor_guardou_perfil', eng['offline'] == ['Gatinho_01'] and eng['sel'] == 'Gatinho_01', eng)
        check('3_uuid_offline_estavel', loc and loc['uuid'] == UU['Gatinho_01'] and loc['name'] == 'Gatinho_01', loc)
        check('3_nome_na_personalizacao', pg.evaluate("document.querySelector('#uname').textContent") == 'Gatinho_01')
        # 4) fechar e abrir: só o armazenamento do "motor" sobrevive (apaga o localStorage do launcher)
        pg.evaluate("Object.keys(localStorage).filter(k=>k.startsWith('cat:')).forEach(k=>localStorage.removeItem(k))")
        pg.reload(); pg.wait_for_timeout(700)
        check('4_conta_mantida_apos_reabrir', pg.evaluate("offProfile()") == {'name': 'Gatinho_01', 'uuid': UU['Gatinho_01']}, pg.evaluate("offProfile()"))
        # 5) JOGAR com conta existente -> launch com esse perfil
        pg.click('#bPlay'); pg.wait_for_timeout(400)
        launch = pg.evaluate("__calls.filter(c=>c[0]==='launch')")
        check('5_jogar_chama_launch_com_perfil', len(launch) == 1 and json.loads(launch[0][2]) == {'u': 'Gatinho_01', 'uuid': UU['Gatinho_01'], 'offline': True}, launch)
        check('5_nao_abre_tela_com_conta', not modal_on())
        # Cancelar fecha sem criar
        pg.evaluate("go('cust')"); pg.click('#bUser'); pg.wait_for_timeout(300); check('5_bUser_abre_tela', modal_on()); pg.click('#offCancel'); pg.wait_for_timeout(200); check('5_cancelar_fecha', not modal_on())
        check('5_cancelar_nao_criou', pg.evaluate("JSON.parse(localStorage.getItem('ENGINE')).offline.length") == 1)
        # 6/7) cabelo
        pg.evaluate("go('cust')"); pg.wait_for_timeout(600)
        base = pg.evaluate(HEAD_BASE); hair0 = pg.evaluate(HAIRCOUNT)
        check('6_cabelo_existe_na_base', hair0 > 25, hair0)
        def holds(label):
            ok = pg.evaluate(HEAD_BASE) == base
            check(label, ok, pg.evaluate(HAIRCOUNT)); return ok
        for c in ['#d32f2f', '#1976d2', '#fbc02d', '#212121', '#f5f5f5', '#f06292', '#fb8c00']:
            pg.click(f".tl[data-k=shirt][data-v='{c}']"); pg.wait_for_timeout(60); holds('6_camisa_' + c)
        pg.click(".tl[data-k=shirt][data-v='#d32f2f']")  # desmarca
        for c in ['#2b4ed1', '#212121', '#8a8a90']:
            pg.click(f".tl[data-k=pants][data-v='{c}']"); holds('7_calca_' + c)
        pg.click(".tl[data-k=pants][data-v='s#fb8c00']"); holds('7_short')
        pg.evaluate("tab='roupas';rail='shoes';panel()")
        for c in ['#212121', '#f5f5f5', '#d32f2f', '#5d4037']:
            pg.click(f".tl[data-k=shoes][data-v='{c}']"); holds('7_sapato_' + c)
        pg.evaluate("rail='shirt';panel()")
        for h in ['#d32f2f', '#1976d2', '#e0b84a', 'helm', 'top']:
            pg.click(f".tl[data-k=hat][data-v='{h}']"); holds('7_chapeu_' + h)
            hat_layer = pg.evaluate("(()=>{const d=tc.getContext('2d').getImageData(32,0,32,16).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i]>0)n++;return n})()")
            check('7_chapeu_vai_para_camada_externa_' + h, hat_layer > 0, hat_layer)
        pg.evaluate("S.sel.hat=undefined;panel()")
        for a in ['shades', 'glasses', 'shades2', 'visor', 'mask', 'tophat', 'bandana']:
            pg.click(f".tl[data-k=acc][data-v='{a}']"); holds('7_acessorio_' + a)
        pg.evaluate("tab='capas';panel()")
        for cp in ['#8b3dff', '#d32f2f']:
            pg.click(f".tl[data-k=cape][data-v='{cp}']"); holds('7_capa_' + cp)
        # tudo junto
        pg.evaluate("S.sel={shirt:'#1976d2',pants:'#212121',shoes:'#d32f2f',hat:'#e0b84a',acc:'shades',cape:'#8b3dff'};paint()")
        holds('7_todos_juntos'); pg.wait_for_timeout(300); pg.screenshot(path=OUT + '/personalizacao_tudo.png')
        # modelo Alex
        pg.evaluate("S.sel={};S.model='alex';paint()")
        a_ok = pg.evaluate(HAIRCOUNT) == hair0; check('7_modelo_alex_mantem_cabelo', a_ok)
        pg.evaluate("S.model='steve';S.sel={};paint()")
        # skin importada (64x64) com cabelo MAGENTA reconhecível + roupa trocada depois
        mk = """(()=>{const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d');x.fillStyle='#c8a07a';x.fillRect(0,0,64,64);x.fillStyle='#ff00ff';x.fillRect(0,0,32,8);x.fillRect(8,8,8,2);x.fillStyle='#10ff10';x.fillRect(32,0,32,6);x.fillStyle='#777';x.fillRect(16,16,24,16);return c.toDataURL('image/png')})()"""
        png = pg.evaluate(mk); import base64; open('/tmp/imp64.png', 'wb').write(base64.b64decode(png.split(',')[1]))
        pg.set_input_files('#fSkin', '/tmp/imp64.png'); pg.wait_for_timeout(500)
        pg.evaluate("tab='roupas';rail='shirt';panel()")
        imp_head = pg.evaluate(HEAD_BASE); hat_imp = pg.evaluate("Array.from(tc.getContext('2d').getImageData(32,0,32,8).data).join(',')")
        pg.click(".tl[data-k=shirt][data-v='#d32f2f']"); pg.wait_for_timeout(100)
        check('7_skin_importada_cabeca_intacta_ao_trocar_camisa', pg.evaluate(HEAD_BASE) == imp_head and pg.evaluate("S.img!==null"))
        check('7_skin_importada_hat_layer_intacta', pg.evaluate("Array.from(tc.getContext('2d').getImageData(32,0,32,8).data).join(',')") == hat_imp)
        check('7_camisa_aplicou_na_importada', pg.evaluate("(()=>{const d=tc.getContext('2d').getImageData(20,20,1,1).data;return d[0]>150&&d[1]<90})()"))
        # skin legada 64x32
        mk32 = mk.replace("c.height=64", "c.height=32").replace("fillRect(0,0,64,64)", "fillRect(0,0,64,32)").replace("x.fillRect(16,16,24,16)", "x.fillRect(0,16,16,8);x.fillStyle='#00f';x.fillRect(40,16,16,8)")
        png32 = pg.evaluate("(()=>{const c=document.createElement('canvas');c.width=64;c.height=32;const x=c.getContext('2d');x.fillStyle='#c8a07a';x.fillRect(0,0,64,32);x.fillStyle='#ff00ff';x.fillRect(0,0,32,8);x.fillStyle='#0000ff';x.fillRect(0,16,16,12);x.fillStyle='#ffa500';x.fillRect(40,16,16,12);return c.toDataURL('image/png')})()")
        open('/tmp/imp32.png', 'wb').write(base64.b64decode(png32.split(',')[1]))
        pg.evaluate("S.sel={};S.img=null;paint()"); pg.set_input_files('#fSkin', '/tmp/imp32.png'); pg.wait_for_timeout(500)
        px = lambda x, y: pg.evaluate(f"Array.from(tc.getContext('2d').getImageData({x},{y},1,1).data)")
        check('7_skin_32_convertida_perna_esq', px(20, 52)[:3] == [0, 0, 255], px(20, 52))
        check('7_skin_32_convertida_braco_esq', px(36, 52)[:3] == [255, 165, 0], px(36, 52))
        check('7_skin_32_cabelo_magenta', px(4, 4)[:3] == [255, 0, 255])
        # 8) salvar mantém
        pg.evaluate("S={model:'steve',sel:{},img:null};paint();panel()")
        pg.evaluate("tab='roupas';rail='shirt';panel()"); pg.click(".tl[data-k=shirt][data-v='#1976d2']"); pg.click(".tl[data-k=hat][data-v='#d32f2f']")
        pg.click('#bSave'); pg.wait_for_timeout(300)
        sv = pg.evaluate("__calls.filter(c=>c[0]==='saveSkin').pop()")
        check('8_salvar_chama_saveSkin_com_png', sv and sv[1]['png'] == 'data:image/png;base64,' and sv[1]['sel'].get('shirt') == '#1976d2' and sv[1]['sel'].get('hat') == '#d32f2f', sv)
        pngsave = pg.evaluate("window.__lastPng"); open(OUT + '/skin_salva.png', 'wb').write(base64.b64decode(pngsave.split(',')[1]))
        pg.reload(); pg.wait_for_timeout(700); pg.evaluate("go('cust')"); pg.wait_for_timeout(400)
        check('8_personalizacao_persiste_ao_reabrir', pg.evaluate("S.sel.shirt==='#1976d2'&&S.sel.hat==='#d32f2f'"))
        check('8_cabelo_apos_reabrir', pg.evaluate(HEAD_BASE) == base)
        pg.screenshot(path=OUT + '/personalizacao_reaberta.png')
        check('0_sem_erros_js', not errs, errs)
        ctx.close()
    shutil.rmtree(prof, ignore_errors=True)
    json.dump(R, open(OUT + '/resultado.json', 'w'), ensure_ascii=False, indent=1)
    print(json.dumps({'passou': len(R) - len(fails), 'total': len(R), 'falhas': fails}, ensure_ascii=False))
    for f in fails: print('FALHA', f, R[f])
main()

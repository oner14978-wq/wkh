//! A data folder's files read from the disk once while a load holds them.
//! Several tables are built from the same folder (the recipes: the crafting
//! tables, the stations, the recipe book, brewing), and each used to list and
//! read every file again: on a hard disk or under a virus scanner, each open
//! costs. The first reader lists and reads the folder; later readers share
//! those bytes for as long as one of them holds the [`Folder`], then it is
//! gone (nothing is kept past the load).
use std::{
    fs, io,
    path::{Path, PathBuf},
    sync::{Arc, Condvar, Mutex, OnceLock, Weak},
};

/// One file: its path inside the folder without `.json` (`a/b`, as an id has
/// it), the file, and its bytes or the error reading it gave.
pub struct File {
    pub name: String,
    pub path: PathBuf,
    bytes: Result<Box<[u8]>, (io::ErrorKind, String)>,
}
impl File {
    pub fn bytes(&self) -> io::Result<&[u8]> {
        self.bytes
            .as_deref()
            .map_err(|(kind, message)| io::Error::new(*kind, message.clone()))
    }
}

/// Every `.json` file under a folder, its subfolders' too, in name order.
pub struct Folder {
    pub files: Vec<File>,
}

static OPEN: Mutex<Vec<(PathBuf, Weak<Folder>)>> = Mutex::new(Vec::new());

/// A loader already reading a folder. Resource tables start on several
/// threads; without this small single-flight gate, two of them can both miss
/// `OPEN` and walk/read the same tag or recipe directory before either has a
/// chance to publish its bytes.
struct InFlight {
    result: Mutex<Option<Result<Arc<Folder>, (io::ErrorKind, String)>>>,
    ready: Condvar,
}
static IN_FLIGHT: OnceLock<Mutex<std::collections::HashMap<PathBuf, Arc<InFlight>>>> =
    OnceLock::new();

fn in_flight() -> &'static Mutex<std::collections::HashMap<PathBuf, Arc<InFlight>>> {
    IN_FLIGHT.get_or_init(|| Mutex::new(std::collections::HashMap::new()))
}

fn find(open: &[(PathBuf, Weak<Folder>)], dir: &Path) -> Option<Arc<Folder>> {
    open.iter()
        .find(|(d, _)| d == dir)
        .and_then(|(_, f)| f.upgrade())
}

/// `dir`'s files if another reader holds them, without reading anything.
pub fn held(dir: &Path) -> Option<Arc<Folder>> {
    find(&OPEN.lock().unwrap_or_else(|e| e.into_inner()), dir)
}

/// The `.json` files under `dir`: shared with any other reader holding them,
/// else listed and read now. An error when `dir` itself can't be listed.
fn read_uncached(dir: &Path) -> io::Result<Arc<Folder>> {
    let files = match prepared(dir) {
        Some(files) => files,
        None => list(dir)?
            .into_iter()
            .map(|(name, path)| {
                let bytes = fs::read(&path)
                    .map(Vec::into_boxed_slice)
                    .map_err(|e| (e.kind(), e.to_string()));
                File { name, path, bytes }
            })
            .collect(),
    };
    let folder = Arc::new(Folder { files });
    let mut open = OPEN.lock().unwrap_or_else(|e| e.into_inner());
    // Another reader may have read it meanwhile: share one copy.
    if let Some(theirs) = find(&open, dir) {
        return Ok(theirs);
    }
    open.retain(|(_, f)| f.strong_count() > 0);
    open.push((dir.to_owned(), Arc::downgrade(&folder)));
    Ok(folder)
}

pub fn read(dir: &Path) -> io::Result<Arc<Folder>> {
    if let Some(folder) = held(dir) {
        return Ok(folder);
    }
    let (flight, leader) = {
        let mut flights = in_flight().lock().unwrap_or_else(|e| e.into_inner());
        match flights.entry(dir.to_owned()) {
            std::collections::hash_map::Entry::Occupied(entry) => (entry.get().clone(), false),
            std::collections::hash_map::Entry::Vacant(entry) => {
                let flight = Arc::new(InFlight {
                    result: Mutex::new(None),
                    ready: Condvar::new(),
                });
                entry.insert(flight.clone());
                (flight, true)
            }
        }
    };
    if !leader {
        let mut result = flight.result.lock().unwrap_or_else(|e| e.into_inner());
        while result.is_none() {
            result = flight.ready.wait(result).unwrap_or_else(|e| e.into_inner());
        }
        return result
            .clone()
            .expect("json folder flight result")
            .map_err(|(kind, message)| io::Error::new(kind, message));
    }

    let result = read_uncached(dir).map_err(|e| (e.kind(), e.to_string()));
    {
        let mut published = flight.result.lock().unwrap_or_else(|e| e.into_inner());
        *published = Some(result.clone());
        flight.ready.notify_all();
    }
    in_flight()
        .lock()
        .unwrap_or_else(|e| e.into_inner())
        .remove(dir);
    result.map_err(|(kind, message)| io::Error::new(kind, message))
}

/// `dir`'s `.json` files from its prepared root's `horizon-data.bin`, when
/// that holds them: one open handle instead of a file opened for each.
fn prepared(dir: &Path) -> Option<Vec<File>> {
    let (data, rel) = horizon_core::prepared_files::find(dir)?;
    let prefix = format!("{rel}/");
    let mut files: Vec<File> = data
        .list(&rel)?
        .into_iter()
        .filter_map(|full| {
            let name = full.strip_prefix(&prefix)?.strip_suffix(".json")?;
            let bytes = data.read(full)?;
            Some(File {
                name: name.to_owned(),
                path: dir.join(format!("{name}.json")),
                bytes: bytes
                    .map(Vec::into_boxed_slice)
                    .map_err(|e| (e.kind(), e.to_string())),
            })
        })
        .collect();
    // In `list`'s order: by id, not by file name.
    files.sort_by(|a, b| a.name.cmp(&b.name));
    Some(files)
}

/// The `.json` files under `dir` and its subfolders, in name order: each
/// one's path inside the folder without the extension (`a/b`) and its file.
/// An error when `dir` itself can't be listed; a subfolder or an entry that
/// can't be is warned and skipped, as vanilla's `PathPackResources` keeps
/// what it found.
pub fn list(dir: &Path) -> io::Result<Vec<(String, PathBuf)>> {
    let mut files = Vec::new();
    let mut stack = vec![fs::read_dir(dir)?];
    while let Some(entries) = stack.pop() {
        for entry in entries {
            let entry = match entry {
                Ok(entry) => entry,
                Err(e) => {
                    log::warn!("Horizon: failed to list an entry of {}: {e}", dir.display());
                    continue;
                }
            };
            let path = entry.path();
            if path.is_dir() {
                match fs::read_dir(&path) {
                    Ok(list) => stack.push(list),
                    Err(e) => log::warn!("Horizon: failed to list {}: {e}", path.display()),
                }
            } else if path.extension().is_some_and(|e| e == "json") {
                files.push(path);
            }
        }
    }
    let mut named: Vec<(String, PathBuf)> = files
        .into_iter()
        .map(|path| {
            let inside = path.strip_prefix(dir).unwrap_or(&path).with_extension("");
            let name: Vec<_> = inside.iter().map(|c| c.to_string_lossy()).collect();
            (name.join("/"), path)
        })
        .collect();
    // Vanilla lists resources by id, in a map keyed by it
    // (`FallbackResourceManager`): `crushing` before `crushing/iron`, where
    // a path's components put the subfolder's file first.
    named.sort_by(|a, b| a.0.cmp(&b.0));
    Ok(named)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn folder(tag: &str) -> PathBuf {
        let dir =
            std::env::temp_dir().join(format!("horizon-json-folder-{tag}-{}", std::process::id()));
        let _ = fs::remove_dir_all(&dir);
        fs::create_dir_all(dir.join("brewing")).unwrap();
        fs::write(dir.join("stick.json"), b"{\"a\":1}").unwrap();
        fs::write(dir.join("brewing/awkward.json"), b"{}").unwrap();
        fs::write(dir.join("notes.txt"), b"not json").unwrap();
        dir
    }

    #[test]
    fn readers_share_the_bytes_while_one_holds_them_and_read_again_after() {
        let dir = folder("share");
        let first = read(&dir).unwrap();
        let names: Vec<_> = first.files.iter().map(|f| f.name.as_str()).collect();
        assert_eq!(names, ["brewing/awkward", "stick"]);
        assert_eq!(first.files[1].bytes().unwrap(), b"{\"a\":1}");
        // Held: a change on the disk isn't seen, the copy read is shared.
        fs::write(dir.join("stick.json"), b"{\"a\":2}").unwrap();
        let second = read(&dir).unwrap();
        assert!(Arc::ptr_eq(&first, &second));
        drop((first, second));
        // Let go: the next reader reads the folder again.
        assert_eq!(read(&dir).unwrap().files[1].bytes().unwrap(), b"{\"a\":2}");
        fs::remove_dir_all(&dir).unwrap();
    }

    /// Under a prepared root with a `horizon-data.bin`, the folder is read
    /// from it: the same files, names and order as the folder's.
    #[test]
    fn a_prepared_root_reads_the_folder_from_its_data_file() {
        let root =
            std::env::temp_dir().join(format!("horizon-json-folder-root-{}", std::process::id()));
        let _ = fs::remove_dir_all(&root);
        let recipes = root.join("data/minecraft/recipe");
        fs::create_dir_all(recipes.join("crushing")).unwrap();
        fs::write(root.join("horizon-resources.json"), b"{}").unwrap();
        fs::write(recipes.join("crushing.json"), b"{\"c\":0}").unwrap();
        fs::write(recipes.join("crushing/iron.json"), b"{\"c\":1}").unwrap();
        fs::write(recipes.join("stick.json"), b"{\"a\":1}").unwrap();
        fs::write(recipes.join("notes.txt"), b"not json").unwrap();
        let from_folder: Vec<_> = list(&recipes)
            .unwrap()
            .into_iter()
            .map(|(n, _)| n)
            .collect();
        horizon_core::prepared_files::write(&root).unwrap();
        // Only the data file still has the stick's first bytes.
        fs::write(recipes.join("stick.json"), b"{\"a\":2}").unwrap();
        let folder = read(&recipes).unwrap();
        let names: Vec<_> = folder.files.iter().map(|f| f.name.clone()).collect();
        assert_eq!(names, from_folder);
        assert_eq!(names, ["crushing", "crushing/iron", "stick"]);
        assert_eq!(folder.files[2].bytes().unwrap(), b"{\"a\":1}");
        assert_eq!(folder.files[2].path, recipes.join("stick.json"));
        drop(folder);
        fs::remove_dir_all(&root).unwrap();
    }

    #[test]
    fn a_folder_that_cannot_be_listed_is_an_error() {
        let dir =
            std::env::temp_dir().join(format!("horizon-json-folder-none-{}", std::process::id()));
        assert!(read(&dir).is_err());
    }
}
